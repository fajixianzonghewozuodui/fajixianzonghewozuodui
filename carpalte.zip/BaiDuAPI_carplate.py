from aip import AipOcr

import cv2
from matplotlib import pyplot as plt

# plt显示彩色图片
def plt_show0(img):
    b, g, r = cv2.split(img)
    img = cv2.merge([r, g, b])
    plt.imshow(img)
    plt.show()

""" 你的 APPID AK SK """
APP_ID = '21249979'
API_KEY = 'fGM9RLBiADHaLvrNeypdQqqn'
SECRET_KEY = 'aw5ACKeKPfYqLXrZXTsWNjf75AY3SQkG'

client = AipOcr(APP_ID, API_KEY, SECRET_KEY)


""" 读取图片 """
def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()

image = get_file_content('image/test4.png')

""" 调用车牌识别 """
result =   client.licensePlate(image)
# 读取待检测图片
origin_image = cv2.imread('image/test4.png')
plt_show0(origin_image)
print(result['words_result']['number'])